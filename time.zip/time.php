<?php
date_default_timezone_set("Africa/Douala"); // Set timezone to Cameroon
echo date("l, d F Y h:i:s A");
