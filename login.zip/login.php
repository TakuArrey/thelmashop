<?php 
session_start();
if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0) {
    header("Location:./");
    exit;
}
require_once('DBConnection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Beta Shop 237</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">

    <script src="./js/jquery-3.6.0.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>

    <style>
        html, body {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: url('./images/plasticgroup5f.jpg') no-repeat center center fixed;
            background-size: cover;
            position: relative;
            overflow: hidden;
            transition: background-color 0.5s ease;
        }
        

        body.dark-mode {
            background-color: #111 !important;
            background-blend-mode: multiply;
        }

        .overlay {
            position: absolute;
            top: 0; left: 0;
            height: 100%;
            width: 100%;
            background: linear-gradient(to bottom right, rgba(0,0,0,0.4), rgba(0,0,0,0.6));
            z-index: 1;
        }

        .login-container {
            z-index: 2;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            min-height: 100vh;
        }

        h1#sys_title {
            font-size: 3rem;
            color: #fff;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.6);
            margin-bottom: 20px;
            text-align: center;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
            width: 100%;
            max-width: 400px;
            transition: transform 0.3s ease;
        }

        .login-card:hover {
            animation: shake 0.4s ease;
        }

        @keyframes shake {
            0% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            50% { transform: translateX(5px); }
            75% { transform: translateX(-5px); }
            100% { transform: translateX(0); }
        }

        .form-control {
            border-radius: 10px;
            background-color: rgba(255, 255, 255, 0.9);
        }

        .btn-login {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            color: white;
            border: none;
            border-radius: 8px;
            transition: 0.3s ease;
        }

        .btn-login:hover {
            background: linear-gradient(to right, #00f2fe, #4facfe);
        }

        .dark-toggle {
            position: fixed;
            top: 15px;
            right: 20px;
            z-index: 3;
            background-color: rgba(0, 0, 0, 0.5);
            border: none;
            color: #fff;
            padding: 10px 15px;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .dark-toggle:hover {
            background-color: rgba(255, 255, 255, 0.4);
            color: #000;
        }

        .pop_msg {
            margin-bottom: 10px;
        }

        @media(max-width: 768px) {
            h1#sys_title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

    <div class="overlay"></div>

    <button class="dark-toggle" onclick="toggleDarkMode()">🌙 Toggle Mode</button>

    <div class="login-container">
        <div>
            <h1 id="sys_title">Beta Shop 237</h1>
            <div class="login-card">
                <form id="login-form">
                    <div class="pop_msg" style="display:none;"></div>
                    <div class="form-group">
                        <label for="username" class="text-light">Username</label>
                        <input type="text" id="username" name="username" class="form-control" required autofocus>
                    </div>
                    <div class="form-group mt-3">
                        <label for="password" class="text-light">Password</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <div class="form-group mt-4 text-end">
                        <button type="submit" class="btn btn-login px-4 py-2">Sign In</button>
                    </div>   
                </form>
            </div>
        </div>
    </div>

    <!-- Optional Background Music -->
    
    <audio autoplay loop>
        <source src="./images/celine Dion.mp3" type="audio/mpeg">
    </audio>
   

<script>
    function toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
    }

    $(function () {
        $('#login-form').submit(function (e) {
            e.preventDefault();
            $('.pop_msg').removeClass('alert alert-success alert-danger').hide().text('');

            let form = $(this);
            let submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).text('Logging in...');

            $.ajax({
                url: './Actions.php?a=login',
                method: 'POST',
                data: form.serialize(),
                dataType: 'JSON',
                error: function (err) {
                    $('.pop_msg').addClass('alert alert-danger').text("An error occurred.").show();
                    submitBtn.prop('disabled', false).text('Sign In');
                },
                success: function (resp) {
                    if (resp.status === 'success') {
                        $('.pop_msg').addClass('alert alert-success').text(resp.msg).show();
                        setTimeout(() => {
                            location.replace('./');
                        }, 2000);
                    } else {
                        $('.pop_msg').addClass('alert alert-danger').text(resp.msg).show();
                        submitBtn.prop('disabled', false).text('Sign In');
                    }
                }
            });
        });
    });
</script>

</body>
</html>
