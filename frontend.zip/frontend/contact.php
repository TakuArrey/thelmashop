<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - Thelma Shop 237</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to bottom right, #f9f9ff, #f0f0ff);
    }
    header {
      background: linear-gradient(to right, blue, violet, red);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: white;
    }
    .logo {
      font-size: 24px;
      font-weight: bold;
    }
    nav {
      display: flex;
      gap: 20px;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }
    nav a:hover {
      color: yellow;
    }
    .contact-section {
      max-width: 900px;
      margin: 40px auto;
      padding: 20px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .contact-section h1 {
      text-align: center;
      margin-bottom: 20px;
    }
    .contact-section p {
      text-align: center;
      margin-bottom: 30px;
      color: #444;
    }
    form {
      display: grid;
      gap: 15px;
    }
    input, textarea {
      padding: 12px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 10px;
    }
    button {
      padding: 12px;
      background-color: blue;
      color: white;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    button:hover {
      background-color: darkblue;
    }
    .footer {
      background: #333;
      color: white;
      padding: 30px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 50px;
    }
    .footer h4 {
      margin-bottom: 10px;
    }
    .footer a {
      color: white;
      text-decoration: none;
      display: block;
      margin-bottom: 5px;
      transition: color 0.3s;
    }
    .footer a:hover {
      color: #ff4081;
    }
    .copyright {
      text-align: center;
      padding: 10px;
      background: black;
      color: white;
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">Thelma Shop 237</div>
    <nav>
      <a href="index.html">Home</a>
      <a href="gallery.html">Gallery</a>
      <a href="services.html">Services</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
      <a href="login.php">Login</a>
    </nav>
  </header>

  <section class="contact-section">
    <h1>Contact Us</h1>
    <p>We'd love to hear from you! Please fill out the form below or reach out via WhatsApp.</p>
    <form action="#" method="POST">
      <input type="text" name="name" placeholder="Your Name" required>
      <input type="email" name="email" placeholder="Your Email" required>
      <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
      <button type="submit">Send Message</button>
    </form>
  </section>

  <div class="footer">
    <div>
      <h4>Services</h4>
      <a href="#">Facebook</a>
      <a href="#">Instagram</a>
      <a href="#">LinkedIn</a>
      <a href="#">TikTok</a>
      <a href="#">WhatsApp</a>
    </div>
    <div>
      <h4>Company</h4>
      <a href="#">Services</a>
      <a href="#">Locations</a>
      <a href="#">About</a>
    </div>
    <div>
      <h4>Global</h4>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
    <div>
      <h4>Upcoming</h4>
      <a href="#">Visit Thelma Shop 237</a>
    </div>
  </div>
  <div class="copyright">
    &copy; 2025 Thelma Shop 237. All rights reserved.
  </div>
</body>
</html>
