<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gallery - Thelma Shop 237</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to bottom right, #f0f0ff, #e0e0ff);
    }
    header {
      background: linear-gradient(to right, blue, violet, red);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: white;
    }
    .logo {
      font-size: 24px;
      font-weight: bold;
    }
    nav {
      display: flex;
      gap: 20px;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }
    nav a:hover {
      color: yellow;
    }
    h1 {
      text-align: center;
      margin: 30px 0 20px;
    }
    .gallery-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      padding: 20px 40px;
    }
    .gallery-container img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 15px;
      transition: transform 0.3s ease;
    }
    .gallery-container img:hover {
      transform: scale(1.05);
    }
    .footer {
      background: #333;
      color: white;
      padding: 30px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 50px;
    }
    .footer h4 {
      margin-bottom: 10px;
    }
    .footer a {
      color: white;
      text-decoration: none;
      display: block;
      margin-bottom: 5px;
      transition: color 0.3s;
    }
    .footer a:hover {
      color: #ff4081;
    }
    .copyright {
      text-align: center;
      padding: 10px;
      background: black;
      color: white;
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">Thelma Shop 237</div>
    <nav>
      <a href="index.html">Home</a>
      <a href="gallery.html">Gallery</a>
      <a href="services.html">Services</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
      <a href="login.php">Login</a>
    </nav>
  </header>

  <h1>Gallery</h1>
  <div class="gallery-container">
    <img src="assets/images/gallery1.jpg" alt="Product 1">
    <img src="assets/images/gallery2.jpg" alt="Product 2">
    <img src="assets/images/gallery3.jpg" alt="Product 3">
    <img src="assets/images/gallery4.jpg" alt="Product 4">
    <img src="assets/images/gallery5.jpg" alt="Product 5">
    <img src="assets/images/gallery6.jpg" alt="Product 6">
  </div>

  <div class="footer">
    <div>
      <h4>Services</h4>
      <a href="#">Facebook</a>
      <a href="#">Instagram</a>
      <a href="#">LinkedIn</a>
      <a href="#">TikTok</a>
      <a href="#">WhatsApp</a>
    </div>
    <div>
      <h4>Company</h4>
      <a href="#">Services</a>
      <a href="#">Locations</a>
      <a href="#">About</a>
    </div>
    <div>
      <h4>Global</h4>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
    <div>
      <h4>Upcoming</h4>
      <a href="#">Visit Thelma Shop 237</a>
    </div>
  </div>
  <div class="copyright">
    &copy; 2025 Thelma Shop 237. All rights reserved.
  </div>
</body>
</html>
