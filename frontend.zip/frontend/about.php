<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Thelma Shop 237</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to bottom right, #fdfdff, #f5f5ff);
    }
    header {
      background: linear-gradient(to right, blue, violet, red);
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: white;
    }
    .logo {
      font-size: 24px;
      font-weight: bold;
    }
    nav {
      display: flex;
      gap: 20px;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }
    nav a:hover {
      color: yellow;
    }
    .about-section {
      max-width: 900px;
      margin: 40px auto;
      padding: 20px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .about-section h1 {
      text-align: center;
      margin-bottom: 20px;
      color: #333;
    }
    .about-section p {
      line-height: 1.6;
      font-size: 16px;
      color: #555;
    }
    .footer {
      background: #333;
      color: white;
      padding: 30px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 50px;
    }
    .footer h4 {
      margin-bottom: 10px;
    }
    .footer a {
      color: white;
      text-decoration: none;
      display: block;
      margin-bottom: 5px;
      transition: color 0.3s;
    }
    .footer a:hover {
      color: #ff4081;
    }
    .copyright {
      text-align: center;
      padding: 10px;
      background: black;
      color: white;
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">Thelma Shop 237</div>
    <nav>
      <a href="index.html">Home</a>
      <a href="gallery.html">Gallery</a>
      <a href="services.html">Services</a>
      <a href="about.html">About</a>
      <a href="contact.html">Contact</a>
      <a href="login.php">Login</a>
    </nav>
  </header>

  <section class="about-section">
    <h1>About Us</h1>
    <p>
      Welcome to <strong>Thelma Shop 237</strong> – Cameroon’s go-to destination for affordable, quality products. We are more than just a shop; we are a growing community focused on delivering value, variety, and customer satisfaction.
    </p>
    <p>
      At Thelma Shop, our journey began with a simple mission: to make shopping more accessible and rewarding for every Cameroonian. Whether you're looking for fashion, gadgets, beauty products, or home essentials, we’ve got you covered.
    </p>
    <p>
      Our commitment to innovation led us to launch both physical and online store options, allowing you to test and buy products with ease. We offer a free trial policy for selected goods and ensure smooth cash-on-delivery services across major towns.
    </p>
    <p>
      With a trusted team of employees and dedicated customer care, Thelma Shop 237 guarantees a shopping experience that’s professional, friendly, and uniquely tailored to your needs.
    </p>
  </section>

  <div class="footer">
    <div>
      <h4>Services</h4>
      <a href="#">Facebook</a>
      <a href="#">Instagram</a>
      <a href="#">LinkedIn</a>
      <a href="#">TikTok</a>
      <a href="#">WhatsApp</a>
    </div>
    <div>
      <h4>Company</h4>
      <a href="#">Services</a>
      <a href="#">Locations</a>
      <a href="#">About</a>
    </div>
    <div>
      <h4>Global</h4>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
    <div>
      <h4>Upcoming</h4>
      <a href="#">Visit Thelma Shop 237</a>
    </div>
  </div>
  <div class="copyright">
    &copy; 2025 Thelma Shop 237. All rights reserved.
  </div>
</body>
</html>
