-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2025 at 05:16 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `betashop`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `category_id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`category_id`, `name`, `description`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'Plastic color chair 101', 'This product is made from gold plastic', 1, 0, '2025-02-14 09:16:23', '2025-04-06 12:42:10'),
(2, 'dinning set 102', 'This Bread is made with milk and honey', 1, 0, '2025-02-14 09:19:04', '2025-04-06 12:42:28'),
(3, 'Robber chair 103', 'This is a sample Category 103', 1, 1, '2025-02-14 09:19:11', '2025-04-06 12:42:35'),
(4, 'palour plastic set 104', 'This is a sample Category 104', 1, 1, '2025-02-14 09:19:18', '2025-04-06 12:42:46'),
(12, 'chinease plasctic chairs 2', 'this chairs are directly from china', 1, 0, '2025-04-08 16:18:41', NULL),
(13, 'plastic set tables', 'this are good qualities set tables use beautiful homes', 1, 0, '2025-04-08 16:19:24', NULL),
(14, 'plastic cups', 'this products are sold in bags... And it is really cheaper when sold in bags', 1, 0, '2025-04-08 19:04:54', NULL),
(15, 'Jars', 'this is a plastic jar', 1, 0, '2025-04-08 19:07:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `product_id` int(30) NOT NULL,
  `product_code` text NOT NULL,
  `category_id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL DEFAULT 0,
  `alert_restock` double NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`product_id`, `product_code`, `category_id`, `name`, `description`, `price`, `alert_restock`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, '23141506', 1, 'plastic chair 101', 'this product is save for resale', 3000, 100, 1, 0, '2025-02-14 09:42:00', '2025-04-06 13:17:52'),
(2, '123456', 2, 'Rubber plastic chair', 'many people always ask this product', 4000, 90, 1, 0, '2025-02-14 09:42:00', '2025-04-06 13:18:07'),
(3, '231415', 2, 'Rubber dinning chair', 'Always made with honey and milk', 6000, 120, 1, 0, '2025-02-14 09:42:00', '2025-04-06 13:18:16'),
(7, '021', 1, 'chinese plastic chairs', 'this is a description', 9000, 19, 1, 1, '2025-04-08 16:12:50', '2025-04-08 19:08:55'),
(8, '0012', 14, 'hand cup', 'this is are plastic cups', 6500, 20, 1, 0, '2025-04-08 19:11:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock_list`
--

CREATE TABLE `stock_list` (
  `stock_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` double NOT NULL DEFAULT 0,
  `expiry_date` datetime NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock_list`
--

INSERT INTO `stock_list` (`stock_id`, `product_id`, `quantity`, `expiry_date`, `date_added`) VALUES
(1, 2, 50, '2025-03-23 00:00:00', '2025-03-23 11:59:29'),
(2, 1, 80, '2025-03-23 00:00:00', '2025-03-23 11:59:56'),
(3, 3, 41, '2025-03-24 00:00:00', '2025-03-24 05:35:31'),
(5, 3, 2, '2025-04-25 00:00:00', '2025-04-08 14:58:34'),
(6, 3, 3, '2025-04-25 00:00:00', '2025-04-08 15:11:29'),
(7, 7, 5, '2025-04-10 00:00:00', '2025-04-08 15:43:12'),
(8, 2, 6, '2025-04-21 00:00:00', '2025-04-08 15:43:31'),
(9, 1, 3, '2025-04-08 00:00:00', '2025-04-08 15:43:46');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_items`
--

CREATE TABLE `transaction_items` (
  `transaction_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` double NOT NULL DEFAULT 0,
  `price` double NOT NULL DEFAULT 0,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_items`
--

INSERT INTO `transaction_items` (`transaction_id`, `product_id`, `quantity`, `price`, `date_added`) VALUES
(1, 1, 4, 10, '2022-02-14 02:12:39'),
(1, 2, 2, 15, '2022-02-14 02:12:39'),
(1, 3, 1, 45, '2022-02-14 02:12:39'),
(4, 3, 1, 45, '2022-02-14 02:38:38'),
(4, 2, 2, 15, '2022-02-14 02:38:38'),
(5, 2, 1, 15, '2022-02-14 02:57:53'),
(5, 1, 2, 10, '2022-02-14 02:57:53'),
(6, 2, 1, 15, '2025-03-23 05:29:41'),
(6, 3, 1, 45, '2025-03-23 05:29:41'),
(7, 7, 1, 9000, '2025-04-08 15:22:19'),
(7, 3, 1, 6000, '2025-04-08 15:22:19'),
(8, 7, 1, 9000, '2025-04-08 15:47:12'),
(8, 1, 1, 3000, '2025-04-08 15:47:12'),
(9, 1, 1, 3000, '2025-04-08 16:10:20'),
(10, 7, 2, 9000, '2025-04-08 17:55:05'),
(10, 3, 1, 6000, '2025-04-08 17:55:05'),
(11, 8, 2, 6500, '2025-04-08 18:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_list`
--

CREATE TABLE `transaction_list` (
  `transaction_id` int(30) NOT NULL,
  `receipt_no` text NOT NULL,
  `total` double NOT NULL DEFAULT 0,
  `tendered_amount` double NOT NULL DEFAULT 0,
  `change` double NOT NULL DEFAULT 0,
  `user_id` int(30) DEFAULT 1,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_list`
--

INSERT INTO `transaction_list` (`transaction_id`, `receipt_no`, `total`, `tendered_amount`, `change`, `user_id`, `date_added`) VALUES
(1, '1644804759', 205, 300, 95, 1, '2022-02-14 02:12:39'),
(2, '1644804881', 1000, 1000, 0, 1, '2022-02-14 02:14:41'),
(4, '1644806318', 125, 150, 25, NULL, '2022-02-14 02:38:38'),
(5, '1644807473', 85, 100, 15, NULL, '2022-02-14 02:57:53'),
(6, '1742707781', 80, 80, 0, 5, '2025-03-23 05:29:41'),
(7, '1744125739', 15000, 15000, 0, 1, '2025-04-08 15:22:19'),
(8, '1744127232', 12000, 12000, 0, 8, '2025-04-08 15:47:12'),
(9, '1744128619', 3000, 3000, 0, 8, '2025-04-08 16:10:19'),
(10, '1744134905', 24000, 24000, 0, 9, '2025-04-08 17:55:05'),
(11, '1744135966', 13000, 13000, 0, 7, '2025-04-08 18:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `user_list`
--

CREATE TABLE `user_list` (
  `user_id` int(30) NOT NULL,
  `fullname` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `type` int(30) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_list`
--

INSERT INTO `user_list` (`user_id`, `fullname`, `username`, `password`, `type`, `status`, `date_created`) VALUES
(1, 'Beta Shop', 'betashop', '17332db217f6acbcd86f47b71a166959', 1, 1, '2022-02-14 00:44:30'),
(5, 'thelma mum1', 'thelma1', 'b4cc344d25a2efe540adbf2678e2304c', 0, 1, '2025-03-23 05:15:01'),
(6, 'thelma mum2', 'thelma2', '897adee371529d5f81cda8dfa9f2b5c3', 0, 1, '2025-03-24 05:34:23'),
(7, 'thelma mum', 'thelmamum', 'b813ff32334f541ccb2100ec5f612211', 1, 1, '2025-04-08 15:15:21'),
(8, 'thelma mum', 'thelma', '19f3cb5e3da2bbe0fcd8de37c2bb8144', 0, 1, '2025-04-08 15:16:07'),
(9, 'kevin kockman', 'kevin', '9d5e3ecdeb4cdb7acfd63075ae046672', 0, 1, '2025-04-08 17:53:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `stock_list`
--
ALTER TABLE `stock_list`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD KEY `product_id` (`product_id`),
  ADD KEY `transaction_id` (`transaction_id`);

--
-- Indexes for table `transaction_list`
--
ALTER TABLE `transaction_list`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_list`
--
ALTER TABLE `user_list`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `category_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `product_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stock_list`
--
ALTER TABLE `stock_list`
  MODIFY `stock_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `transaction_list`
--
ALTER TABLE `transaction_list`
  MODIFY `transaction_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_list`
--
ALTER TABLE `user_list`
  MODIFY `user_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_list`
--
ALTER TABLE `product_list`
  ADD CONSTRAINT `product_list_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category_list` (`category_id`) ON DELETE CASCADE;

--
-- Constraints for table `stock_list`
--
ALTER TABLE `stock_list`
  ADD CONSTRAINT `stock_list_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `transaction_items`
--
ALTER TABLE `transaction_items`
  ADD CONSTRAINT `transaction_items_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_items_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`transaction_id`) ON DELETE CASCADE;

--
-- Constraints for table `transaction_list`
--
ALTER TABLE `transaction_list`
  ADD CONSTRAINT `transaction_list_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_list` (`user_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
