
<?php
// session_start();
// if(!isset($_SESSION['user_id'])){
//     header("Location:./login.php");
//     exit;
// }
// require_once('DBConnection.php');
// $page = isset($_GET['page']) ? $_GET['page'] : '../backend/home';
// if($_SESSION['type'] != 1 && in_array($page,array('maintenance','products','stocks'))){
//     header("Location:./");
//     exit;
// }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BETA Shop 237 - Home</title>
  <style>
    /* === INTERNAL CSS === */
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to bottom right, white, #e0e0ff);
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 30px;
      background: linear-gradient(to right, blue, violet, red);
      color: white;
    }
    .logo {
      font-size: 24px;
      font-weight: bold;
    }
    nav {
      display: flex;
      gap: 20px;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s;
    }
    nav a:hover {
      color: yellow;
    }
    .main {
      padding: 30px;
    }
    .carousel {
      width: 100%;
      max-width: 700px;
      margin: auto;
      position: relative;
    }
    .carousel img {
      width: 100%;
      border-radius: 20px;
    }
    .rotating-imgsss {
      display: flex;
      justify-content: space-around;
      margin-top: 30px;
    }
    .rotating-imgss {
      display: flex;
      justify-content: space-around;
      margin-top: 30px;
    }
    .rotating-imgs {
      display: flex;
      justify-content: space-around;
      margin-top: 30px;
    }
    .rotating-imgs img {
      width: 300px;
      height: 150px;
      border-radius: 15px;
      animation: rotate 8s infinite linear;
    }
    .rotating-imgss img {
      width: 300px;
      height: 150px;
      border-radius: 15px;
      animation: rotate 15s infinite linear;
    }
    .rotating-imgsss img {
      width: 300px;
      height: 150px;
      border-radius: 15px;
      animation: rotate 12s infinite linear;
    }
    @keyframes rotate {
      0% {transform: rotateY(0deg);}
      100% {transform: rotateY(360deg);}
    }
    .footer {
      background: #333;
      color: white;
      padding: 30px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
    }
    .footer h4 {
      margin-bottom: 10px;
    }
    .footer a {
      display: block;
      color: white;
      text-decoration: none;
      margin-bottom: 5px;
      transition: color 0.3s;
    }
    .footer a:hover {
      color: #ff4081;
    }
    .copyright {
      text-align: center;
      padding: 10px;
      background: black;
      color: white;
    }
    .whatsapp-btn {
      display: inline-block;
      padding: 10px 15px;
      margin: 15px;
      background: #25D366;
      color: white;
      border-radius: 25px;
      text-decoration: none;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <!-- === HEADER === -->
  <header>
    <div class="logo">BETA Shop 237</div>
    <nav>
      <a href="gallery.php">Gallery</a>
      <a href="news.php">News</a>
      <a href="location.php">Location</a>
    </nav>
    <nav>
      <a href="index.php">Home</a>
      <a href="./frontend/services.php">Services</a>
      <a href="">About</a>
      <a href="">Upcoming</a>
      <a href="">Contact</a>
      <a href="./backend/login.php">Login</a>
    </nav>
  </header>

  <!-- === BODY === -->
  <div class="main">
    <h2 style="text-align:center;">What we can offer you for being our best clients?</h2>
    
    <p style="text-align:center; margin-top: 15px;">Join Beta Shop for unbeatable service and affordable prices.</p>

    <div class="rotating-imgs">
      <img src="img/chair4.jpg">
      <img src="img/chair2.jpg">
      <img src="img/chair 3.jpg">
    </div>
    
        
        
    <div class="rotating-imgsss">
      <img src="./backend/images/plasticgroup5f.jpg">
      <img src="./backend/images/plastic5.jpg">
      <img src="./backend/images/plasticchair1.jpg">
    </div>

    <div class="rotating-imgss">
    <img src="./backend/images/setdinning1.jpg">
      <img src="img/chair2.jpg">
      <img src="./backend/images/setdinning1.jpg">
    </div>
    <p style="text-align:center;">BETA Shop is the best in Cameroon!</p>

    <div style="text-align:center;">
      <p>Buy cheap and affordable goods or test for free!</p>
      <a class="whatsapp-btn" href="https://wa.me/237682331965">Contact Now</a>
      <a class="whatsapp-btn" href="https://wa.me/237682331965">Connect Us</a>
    </div>
  </div>

  <!-- === FOOTER === -->
  <div class="footer">
    <div>
      <h4>Services</h4>
      <a href="#">Facebook</a>
      <a href="#">Instagram</a>
      <a href="#">LinkedIn</a>
      <a href="#">TikTok</a>
      <a href="#">WhatsApp</a>
    </div>
    <div>
      <h4>Company</h4>
      <a href="#">Services</a>
      <a href="#">Locations</a>
      <a href="#">About</a>
    </div>
    <div>
      <h4>Global</h4>
      <a href="#">Privacy Policy</a>
      <a href="#">Terms of Service</a>
    </div>
    <div>
      <h4>Upcoming</h4>
      <a href="#">Visit Thelma Shop 237</a>
    </div>
  </div>
  <div class="copyright">
    &copy; 2025 BETA Shop 237. All rights reserved.
  </div>

  <!-- === JS for Carousel === -->
  <script>
    // let current = 1;
    // const total = 6;
    // setInterval(() => {
    //   document.getElementById('slide').src = `img/chair4${current}.jpg`;
    //   current = (current % total) + 1;
    // }, 3000);
  </script>
</body>
</html>
